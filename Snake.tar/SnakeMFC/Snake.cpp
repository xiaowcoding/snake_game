#pragma once
#include "stdafx.h"
#include "Snake.h"

CSnake::CSnake()
	: p_SnakeHead(NULL)
{
	p_SnakeHead = (SnakeBody*)malloc(sizeof(SnakeBody));//��ʼ���ߵ�����
	p_SnakeHead->x = 16;
	p_SnakeHead->y = 12;
	p_SnakeHead->pre = NULL;
	p_SnakeTail = p_SnakeHead;
	for (int i = 1; i < 2; i++)
	{
		SnakeBody *p = (SnakeBody*)malloc(sizeof(SnakeBody));
		p->x = 16 + i;
		p->y = 12;
		p->pre = p_SnakeTail;
		p_SnakeTail->next = p;
		p_SnakeTail = p;
		p_SnakeTail->next = NULL;
	}

	m_derector = 'L';//��ʼ������ ����
}


CSnake::~CSnake()
{
}


SnakeBody * CSnake::GetHead()
{
	return p_SnakeHead;
}

void CSnake::SnakeInitial()
{
	p_SnakeHead = (SnakeBody*)malloc(sizeof(SnakeBody));//��ʼ���ߵ�����
	p_SnakeHead->x = 16;
	p_SnakeHead->y = 12;
	p_SnakeHead->pre = NULL;
	p_SnakeTail = p_SnakeHead;
	for (int i = 1; i < 2; i++)
	{
		SnakeBody *p = (SnakeBody*)malloc(sizeof(SnakeBody));
		p->x = 16 + i;
		p->y = 12;
		p->pre = p_SnakeTail;
		p_SnakeTail->next = p;
		p_SnakeTail = p;
		p_SnakeTail->next = NULL;
	}

	m_derector = 'L';//��ʼ������ ����
}


void CSnake::Move()
{
	rec.SetRect((p_SnakeTail->x)*20, (p_SnakeTail->y)*20, ((p_SnakeTail->x) + 1)*20, ((p_SnakeTail->y) + 1)*20);

	SnakeBody *p = p_SnakeTail->pre;//β�ڵ�
	p_SnakeTail->x = p->x;
	p_SnakeTail->y = p->y;

	SnakeBody * q = p->pre;//�м�ڵ�
	while (q)
	{
		p->x = q->x;
		p->y = q->y;
		p = q;
		q = p->pre;
	}

	switch (m_derector)//ͷ�ڵ�
	{
	case 'U':
		p_SnakeHead->y -= 1;
		break;
	case 'D':
		p_SnakeHead->y += 1;
		break;
	case 'L':
		p_SnakeHead->x -= 1;
		break;
	case 'R':
		p_SnakeHead->x += 1;
		break;
	default:
		break;
	}
}


char CSnake::GetDerector()
{
	return m_derector;
}


void CSnake::SetDerector(char der)
{
	m_derector = der;
}


SnakeBody * CSnake::GetTail()
{
	return p_SnakeTail;
}