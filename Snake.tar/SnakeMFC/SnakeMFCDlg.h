
// SnakeMFCDlg.h : ͷ�ļ�
//

#pragma once
#include "atltypes.h"
#include "Snake.h"
#include "afxwin.h"

// CSnakeMFCDlg �Ի���
class CSnakeMFCDlg : public CDialogEx
{
// ����
public:
	CSnakeMFCDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SNAKEMFC_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	void CreatFood();
private:
	CPoint food;
public:
	void DrawFood();
private:
	CSnake snake;
public:
	void DrawSnake();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	void Judge();
	void EatFood();
private:
	CString m_grade;
	CString m_dengji;
public:
	afx_msg void OnBnClickedButtonStart();
	afx_msg void OnBnClickedButtonRestart();
	afx_msg void OnBnClickedButtonExit();
	afx_msg void OnBnClickedButtonRuler();
};
