#pragma once
#include "atltypes.h"

typedef struct Stuctsnake
{
	int x;
	int y;
	Stuctsnake *pre;
	Stuctsnake *next;
}SnakeBody;
class CSnake
{
public:
	CSnake();
	~CSnake();
	
	Stuctsnake *p_SnakeHead; 
	SnakeBody *p_SnakeTail; 
	char m_derector;

	Stuctsnake * GetHead();
	void SnakeInitial();
	void Move();
	char GetDerector();
	void SetDerector(char der);
	SnakeBody * GetTail();
	CRect rec;
};